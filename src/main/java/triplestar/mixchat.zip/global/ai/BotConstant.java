package triplestar.mixchat.global.ai;

public class BotConstant {
    public static final Long BOT_MEMBER_ID = 101L;
}

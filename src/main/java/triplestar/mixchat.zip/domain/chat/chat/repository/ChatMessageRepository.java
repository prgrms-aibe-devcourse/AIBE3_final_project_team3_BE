package triplestar.mixchat.domain.chat.chat.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.Aggregation;
import org.springframework.data.mongodb.repository.MongoRepository;
import triplestar.mixchat.domain.chat.chat.constant.ChatRoomType;
import triplestar.mixchat.domain.chat.chat.entity.ChatMessage;

public interface ChatMessageRepository extends MongoRepository<ChatMessage, String> {
    // 기존: 전체 메시지 조회 (하위 호환성 유지)
    List<ChatMessage> findByChatRoomIdAndChatRoomTypeOrderByCreatedAtAsc(Long chatRoomId, ChatRoomType chatRoomType);

    // 페이징: 최신 메시지부터 N개 (sequence 내림차순)
    List<ChatMessage> findByChatRoomIdAndChatRoomTypeOrderBySequenceDesc(
        Long chatRoomId,
        ChatRoomType chatRoomType,
        Pageable pageable
    );

    // 페이징: cursor 이전 메시지 N개 (sequence < cursor, 내림차순)
    List<ChatMessage> findByChatRoomIdAndChatRoomTypeAndSequenceLessThanOrderBySequenceDesc(
        Long chatRoomId,
        ChatRoomType chatRoomType,
        Long sequence,
        Pageable pageable
    );

    // [추가] 페이징 + 입장 시간 필터: 최신 메시지부터 N개
    List<ChatMessage> findByChatRoomIdAndChatRoomTypeAndCreatedAtGreaterThanEqualOrderBySequenceDesc(
            Long chatRoomId,
            ChatRoomType chatRoomType,
            LocalDateTime joinDate,
            Pageable pageable
    );

    // [추가] 페이징 + 입장 시간 필터: cursor 이전 메시지 N개
    List<ChatMessage> findByChatRoomIdAndChatRoomTypeAndSequenceLessThanAndCreatedAtGreaterThanEqualOrderBySequenceDesc(
            Long chatRoomId,
            ChatRoomType chatRoomType,
            Long sequence,
            LocalDateTime joinDate,
            Pageable pageable
    );

    // 특정 채팅방의 최신 메시지 1개 조회
    Optional<ChatMessage> findTopByChatRoomIdAndChatRoomTypeOrderBySequenceDesc(
            Long chatRoomId,
            ChatRoomType chatRoomType
    );

    List<ChatMessage> findByChatRoomIdAndChatRoomTypeOrderByCreatedAtDescIdDesc(
            Long roomId,
            ChatRoomType chatRoomType,
            Pageable pageable
    );

    // Load Test Cleanup: 특정 채팅방의 모든 메시지 삭제 (MongoDB)
    void deleteByChatRoomIdAndChatRoomType(Long chatRoomId, ChatRoomType chatRoomType);

    // Load Test Cleanup: 삭제 전 카운트 확인용
    long countByChatRoomIdAndChatRoomType(Long chatRoomId, ChatRoomType chatRoomType);

    // 여러 채팅방의 최신 메시지 내용을 한번에 조회 (Batch Query)
    // MongoDB Aggregation: 각 roomId별로 최신 메시지의 content를 반환
    @Aggregation(pipeline = {
        "{ $match: { chatRoomId: { $in: ?0 }, chatRoomType: ?1 } }",
        "{ $sort: { sequence: -1 } }",
        "{ $group: { " +
            "_id: '$chatRoomId', " +
            "content: { $first: { $cond: [ " +
                "{ $and: [ { $eq: ['$isTranslateEnabled', true] }, { $ne: ['$translatedContent', null] } ] }, " +
                "'$translatedContent', " +
                "'$content' " +
            "] } }, " +
            "created_at: { $first: '$created_at' }, " +
            "sequence: { $first: '$sequence' } " +
        "} }",
        "{ $project: { chatRoomId: '$_id', content: 1, created_at: 1, sequence: 1, _id: 0 } }"
    })
    List<LatestMessageContent> findLatestMessageContentByRoomIds(List<Long> roomIds, ChatRoomType chatRoomType);

    // Projection interface for the aggregation result
    interface LatestMessageContent {
        Long getChatRoomId();
        String getContent();
        java.util.Date getCreated_at();  // MongoDB 필드명과 일치
        Long getSequence();
    }
}

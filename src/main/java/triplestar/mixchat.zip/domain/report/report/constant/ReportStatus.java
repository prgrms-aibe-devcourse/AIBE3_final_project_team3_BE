package triplestar.mixchat.domain.report.report.constant;

public enum ReportStatus {
    WAITING,
    APPROVED,
    REJECTED;
}
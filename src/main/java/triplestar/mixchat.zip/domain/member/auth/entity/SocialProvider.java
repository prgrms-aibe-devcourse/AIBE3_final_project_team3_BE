package triplestar.mixchat.domain.member.auth.entity;

public enum SocialProvider {
    GOOGLE,
    KAKAO,
    NAVER,
    ;
}

package triplestar.mixchat.domain.member.auth.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QSocialMember is a Querydsl query type for SocialMember
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QSocialMember extends EntityPathBase<SocialMember> {

    private static final long serialVersionUID = -756650866L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QSocialMember socialMember = new QSocialMember("socialMember");

    public final triplestar.mixchat.global.jpa.entity.QBaseEntity _super = new triplestar.mixchat.global.jpa.entity.QBaseEntity(this);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createdAt = _super.createdAt;

    //inherited
    public final NumberPath<Long> id = _super.id;

    public final triplestar.mixchat.domain.member.member.entity.QMember member;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> modifiedAt = _super.modifiedAt;

    public final StringPath socialId = createString("socialId");

    public final EnumPath<SocialProvider> socialProvider = createEnum("socialProvider", SocialProvider.class);

    public QSocialMember(String variable) {
        this(SocialMember.class, forVariable(variable), INITS);
    }

    public QSocialMember(Path<? extends SocialMember> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QSocialMember(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QSocialMember(PathMetadata metadata, PathInits inits) {
        this(SocialMember.class, metadata, inits);
    }

    public QSocialMember(Class<? extends SocialMember> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.member = inits.isInitialized("member") ? new triplestar.mixchat.domain.member.member.entity.QMember(forProperty("member"), inits.get("member")) : null;
    }

}


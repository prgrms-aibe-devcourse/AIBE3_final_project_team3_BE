package triplestar.mixchat.domain.chat.chat.constant;

public enum ChatNotificationSetting {
    ALWAYS,
//    MENTIONS_ONLY,
    NONE
}

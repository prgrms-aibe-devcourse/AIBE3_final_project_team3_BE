package triplestar.mixchat.domain.chat.chat.constant;

public enum AiChatRoomType {
    ROLE_PLAY,        // 상황극 기반 학습
    TUTOR_PERSONAL,  // 개인화 RAG tutor
    TUTOR_SIMILAR,   // 유사도 기반 tutor
}

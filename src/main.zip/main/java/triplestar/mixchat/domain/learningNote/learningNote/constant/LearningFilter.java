package triplestar.mixchat.domain.learningNote.learningNote.constant;

public enum LearningFilter {
    ALL,
    LEARNED,
    UNLEARNED
}
package triplestar.mixchat.domain.ai.rag.context.user;

public enum ContextChunkType {
    LEARNING_NOTE,
    FEEDBACK,
}

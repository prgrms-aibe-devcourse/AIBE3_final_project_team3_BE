package triplestar.mixchat.domain.member.member.constant;

public enum EnglishLevel {
    BEGINNER,
    INTERMEDIATE,
    ADVANCED,
    NATIVE
}

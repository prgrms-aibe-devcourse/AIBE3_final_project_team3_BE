package triplestar.mixchat.domain.member.friend.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import triplestar.mixchat.domain.member.friend.dto.FriendDetailResp;
import triplestar.mixchat.domain.member.friend.dto.FriendSummaryResp;
import triplestar.mixchat.domain.member.friend.dto.FriendshipRequestResp;
import triplestar.mixchat.domain.member.friend.dto.FriendshipSendReq;
import triplestar.mixchat.domain.member.friend.service.FriendshipRequestService;
import triplestar.mixchat.domain.member.friend.service.FriendshipService;
import triplestar.mixchat.global.response.CustomResponse;
import triplestar.mixchat.global.security.CustomUserDetails;

@RestController
@RequiredArgsConstructor
@RequestMapping("api/v1/members/friends")
public class ApiV1FriendshipController implements ApiFriendshipController {

    private final FriendshipRequestService friendshipRequestService;
    private final FriendshipService friendshipService;

    @Override
    @PostMapping
    public CustomResponse<FriendshipRequestResp> sendFriendRequest(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @RequestBody FriendshipSendReq req
    ) {
        Long memberId = userDetails.getId();
        FriendshipRequestResp resp = friendshipRequestService.sendRequest(memberId, req.receiverId());

        return CustomResponse.ok("친구 요청이 성공적으로 전송되었습니다.", resp);
    }

    @Override
    @PatchMapping("/{requestId}/accept")
    public CustomResponse<Void> acceptRequest(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @PathVariable Long requestId
    ) {
        Long memberId = userDetails.getId();
        friendshipRequestService.processRequest(memberId, requestId, true);

        return CustomResponse.ok("친구 요청이 수락되었습니다.");
    }

    @Override
    @PatchMapping("/{requestId}/reject")
    public CustomResponse<Void> rejectRequest(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @PathVariable Long requestId
    ) {
        Long memberId = userDetails.getId();
        friendshipRequestService.processRequest(memberId, requestId, false);

        return CustomResponse.ok("친구 요청이 거절되었습니다.");
    }

    @Override
    @DeleteMapping("/{friendId}")
    public CustomResponse<Void> deleteFriend(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @PathVariable Long friendId
    ) {
        Long memberId = userDetails.getId();
        friendshipService.deleteFriendship(memberId, friendId);

        return CustomResponse.ok("친구가 성공적으로 삭제되었습니다.");
    }

    @Override
    @GetMapping
    public CustomResponse<Page<FriendSummaryResp>> getFriends(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @PageableDefault(size = 20) Pageable pageable
    ) {
        Page<FriendSummaryResp> resp = friendshipService.getFriends(userDetails.getId(), pageable);
        return CustomResponse.ok("친구 목록이 성공적으로 조회되었습니다.", resp);
    }

    @Override
    @GetMapping("/{friendId}")
    public CustomResponse<FriendDetailResp> getFriend(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @PathVariable Long friendId
    ) {
        Long memberId = userDetails.getId();
        FriendDetailResp resp = friendshipService.getFriend(memberId, friendId);

        return CustomResponse.ok("친구 정보가 성공적으로 조회되었습니다.", resp);
    }
}

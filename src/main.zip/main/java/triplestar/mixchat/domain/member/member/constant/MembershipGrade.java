package triplestar.mixchat.domain.member.member.constant;

public enum MembershipGrade {
    BASIC,
    PREMIUM
}

package triplestar.mixchat.domain.member.member.service;

import jakarta.persistence.EntityNotFoundException;
import java.util.List;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import triplestar.mixchat.domain.member.friend.dto.FriendshipStateInfo;
import triplestar.mixchat.domain.member.friend.repository.FriendshipRepository;
import triplestar.mixchat.domain.member.member.constant.ProfileImageProperties;
import triplestar.mixchat.domain.member.member.dto.MemberDetailResp;
import triplestar.mixchat.domain.member.member.dto.MemberInfoModifyReq;
import triplestar.mixchat.domain.member.member.dto.MemberPresenceSummaryResp;
import triplestar.mixchat.domain.member.member.dto.MyProfileResp;
import triplestar.mixchat.domain.member.member.entity.Member;
import triplestar.mixchat.domain.member.member.repository.MemberRepository;
import triplestar.mixchat.domain.member.presence.service.PresenceService;
import triplestar.mixchat.global.s3.S3Uploader;

@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class MemberService {

    private final MemberRepository memberRepository;
    private final FriendshipRepository friendshipRepository;
    private final S3Uploader s3Uploader;
    private final PresenceService presenceService;
    private final ProfileImageProperties profileImageProperties;

    private Member findMemberById(Long memberId) {
        return memberRepository.findById(memberId)
                .orElseThrow(() -> new EntityNotFoundException("존재하지 않는 회원입니다."));
    }

    public MyProfileResp getMyProfile(Long currentUserId) {
        return MyProfileResp.from(findMemberById(currentUserId));
    }

    public MemberDetailResp getMemberDetails(Long currentUserId, Long memberId) {
        Member member = findMemberById(memberId);
        if (member.isNotAccessible()) {
            throw new IllegalStateException("조회할 수 없는 회원입니다.");
        }

        // 비회원이 조회하는 경우 : 친구 관계 정보는 제공하지 않음
        if (currentUserId == null) {
            return MemberDetailResp.forAnonymousViewer(member);
        }

        // 회원이 조회하는 경우 : 친구 관계 및 친구 신청 상태를 함께 조회
        FriendshipStateInfo friendshipStateInfo = friendshipRepository.findFriendshipStateInfo(currentUserId, memberId);
        return MemberDetailResp.from(member, friendshipStateInfo);
    }

    // NOTE : 현재 로그인한 사용자를 제외한 모든 회원 조회 -> 추후 로그인 사용자도 포함시킬지 검토 필요
    public Page<MemberPresenceSummaryResp> findAllMembers(Long currentUserId, Pageable pageable) {
        Page<Member> members = memberRepository.findAllByIdIsNot(currentUserId, pageable);

        List<Long> ids = members.stream().map(Member::getId).toList();
        Set<Long> onlineIds = presenceService.filterIsOnline(ids);

        return members.map(member ->
                MemberPresenceSummaryResp.from(member, onlineIds.contains(member.getId())));
    }

    // NOTE : 현재 로그인한 사용자를 제외한 모든 회원 조회 -> 추후 로그인 사용자도 포함시킬지 검토 필요
    public Page<MemberPresenceSummaryResp> findOnlineMembers(Long currentUserId, Pageable pageable) {
        List<Long> onlineMemberIds = presenceService.getOnlineMemberIds(pageable.getOffset(), pageable.getPageSize());
        Page<Member> members = memberRepository.findByIds(currentUserId, onlineMemberIds, pageable);

        return members.map(member -> MemberPresenceSummaryResp.from(member, true));
    }

    @Transactional
    public void updateInfo(Long memberId, MemberInfoModifyReq req) {
        Member member = findMemberById(memberId);

        member.updateInfo(req.name(),
                req.nickname(),
                req.country(),
                req.englishLevel(),
                req.interests(),
                req.description());
    }

    @Transactional
    public void uploadProfileImage(Long memberId, MultipartFile multipartFile) {
        String defaultProfileImageUrl = profileImageProperties.defaultProfileImageUrl();
        Long maxProfileImageSize = profileImageProperties.maxProfileImageSizeBytes();
        Set<String> allowedImageTypes = profileImageProperties.allowedImageTypes();

        Member member = findMemberById(memberId);

        if (multipartFile == null || multipartFile.isEmpty()) {
            member.updateProfileImageUrl(defaultProfileImageUrl);
            return;
        }

        if (multipartFile.getSize() > maxProfileImageSize) {
            throw new IllegalArgumentException("프로필 사진 최대 크기: " + (maxProfileImageSize / (1024 * 1024)) + "MB");
        }

        String contentType = multipartFile.getContentType();
        if (contentType == null || !allowedImageTypes.contains(contentType)) {
            throw new IllegalArgumentException("허용되지 않는 이미지 형식입니다.");
        }

        String url = s3Uploader.uploadFile(multipartFile, "member/profile");

        member.updateProfileImageUrl(url);
    }

    @Transactional
    public void deleteSoftly(Long memberId) {
        String defaultProfileImageUrl = profileImageProperties.defaultProfileImageUrl();

        Member member = findMemberById(memberId);
        String profileUrl = member.getProfileImageUrl();
        if (profileUrl != null && !profileUrl.equals(defaultProfileImageUrl)) {
            s3Uploader.deleteFileByUrl(profileUrl);
        }

        member.deleteSoftly();
        member.updateProfileImageUrl(defaultProfileImageUrl);
    }
}

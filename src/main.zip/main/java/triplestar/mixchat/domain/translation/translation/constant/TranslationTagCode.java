package triplestar.mixchat.domain.translation.translation.constant;

public enum TranslationTagCode {
    ALL,
    GRAMMAR,
    VOCABULARY,
    TRANSLATION;
}